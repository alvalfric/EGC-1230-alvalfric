from django.contrib import admin

from .models import Auth, Key


admin.site.register(Auth)
admin.site.register(Key)
